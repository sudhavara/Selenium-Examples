package E2EProject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class BaseClass implements  AllPagesInterface{

    WebDriver driver = null;
    BasePage basepage = new BasePage();
    LoginPage loginpage = new LoginPage();
    LandingPage landingpage = new LandingPage();


    @Override
    public WebDriver basePage() {

        basepage.driverInitiation();
        System.out.println("driver initiation done in base class");
        return driver;
    }

    @Override
    public WebElement landingPage() {
        System.out.println("landed on home page");
        WebElement loginbutton =landingpage.getLoginbutton(driver);
        WebElement aboutbutton=landingpage.getAboutbutton(driver);
        WebElement compareButton=landingpage.getComparebutton(driver);
        WebElement pricingButton=landingpage.getPricingbutton(driver);
        WebElement iTunesButton= landingpage.getItunesImage(driver);
        WebElement androidButton=landingpage.getAndroidImage(driver);
        WebElement supportButton=landingpage.getSupport(driver);

        return loginbutton;
    }

    @Override
    public WebElement loginPage() {


        WebElement Emailid =loginpage.getEmailId(driver);
        loginpage.getEmailId(driver);
        System.out.println("Email id retrieved");
        loginpage.getPassword(driver);
        System.out.println("password id retrieved");
        loginpage.getSubmit(driver);

        return null;
    }




}
