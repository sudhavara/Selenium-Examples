package E2EProject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LandingPage {

    WebDriver driver;
    By login = By.cssSelector("a[href='https://ui.cogmento.com']");
    By about = By.xpath("//a[@href='about.html']");
    By compare=By.xpath("//a[@href='compare.html']");
    By pricing=By.xpath("//a[@href='pricing.html']");
    By iTunesimage=By.xpath("//img[@alt='iTunes']");
    By android= By.xpath("//img[@alt='Android']");
    By support = By.xpath("//a[@href='https://support.cogmento.com/webinars-and-videos']");



    public WebElement getLoginbutton(WebDriver driver) {
        System.out.println("entered in to getLoginbutton method");
        return  driver.findElement(login);
        }
    public WebElement getAboutbutton(WebDriver driver) {
        System.out.println("entered in to getAboutbutton method");
        return  driver.findElement(about);
    }
    public WebElement getComparebutton(WebDriver driver) {
        System.out.println("entered in to getComparebutton method");
        return  driver.findElement(compare);
    }
    public WebElement getPricingbutton(WebDriver driver) {
        System.out.println("entered in to getPricingbutton method");
        return  driver.findElement(pricing);
    }
    public WebElement getItunesImage(WebDriver driver) {
        System.out.println("entered in to getItunesImage method");
        return  driver.findElement(iTunesimage);
    }
    public WebElement getAndroidImage(WebDriver driver) {
        System.out.println("entered in to getAndroidImage method");
        return  driver.findElement(android);
    }
    public WebElement getSupport(WebDriver driver) {
        System.out.println("entered in to getSupport method");
        return  driver.findElement(support);
    }





}
