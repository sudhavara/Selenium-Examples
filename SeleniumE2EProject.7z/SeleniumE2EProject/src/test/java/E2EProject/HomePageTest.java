package E2EProject;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.net.HttpURLConnection;
import java.net.URL;

public class HomePageTest extends BaseClass{

    WebDriver driver = null;
    String strlinkURL;

    @Test

    public void validLinks() {
        driver = basepage.driverInitiation();
        driver.get("https://freecrm.com/");
        landingpage.getAboutbutton(driver).click();
        strlinkURL =driver.getCurrentUrl();
        HttpURLConnection connection = (HttpURLConnection)new URL(strlinkURL).openConnection();
        connection.connect();

        Assert.assertEquals(driver.getTitle(),"Cloud CRM since 2003");
        Assert.assertEquals(strlinkURL,"https://freecrm.com/about.html");

    }


    @Test(dataProvider = "getData")
    public void testCase1(String strusername,String strpassword) throws InterruptedException {
        driver = basepage.driverInitiation();
        driver.get("https://freecrm.com/");
        landingpage.getLoginbutton(driver).click();
        Thread.sleep(3000);
        loginpage.getEmailId(driver).sendKeys(strusername);
        loginpage.getPassword(driver).sendKeys(strpassword);
        loginpage.getSubmit(driver).click();
        basepage.driverclose(driver);

    }

    @DataProvider

    public Object[][] getData(){
        //for two entries three columns data means attributes data
        Object[][] data = new Object[1][2];
        data[0][0]="nonrestricteduser@gmail.com";
        data[0][1]="password1";
       // data[0][2]="nonrestricted user";


        data[0][0]="restricteduser@gmail.com";
        data[0][1]="password2";
        //data[0][2]="restricted user";

        return data;
    }





}
