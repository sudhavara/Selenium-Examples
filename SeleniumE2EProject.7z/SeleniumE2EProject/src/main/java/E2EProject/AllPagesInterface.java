package E2EProject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.io.IOException;

public interface AllPagesInterface {

     WebDriver driver = null;

     public WebDriver basePage();
     public WebElement landingPage();
     public WebElement loginPage();







}
